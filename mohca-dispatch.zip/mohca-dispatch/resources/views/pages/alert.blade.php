<!-- /resources/views/alert.blade.php -->

<div class="alert alert-danger">

    <div class="alert-title"><p>{{ $title }}</p></div>
    {{ $slot }}
     
</div>