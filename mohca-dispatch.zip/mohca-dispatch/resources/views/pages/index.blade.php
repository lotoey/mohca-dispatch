<!-- Stored in resources/views/pages/index.blade.php -->

@extends('layouts.mainlayout')

@section('title', 'Dispatch')

@section('sidebar')
    @parent
    <p>This is appended to the master sidebar.</p>
@endsection

@section('content')
<div class="wrapper">
  <div class="container">
  <div class="row">
      @include('layouts.sidenav')
      <div class="col-2">
        One of three columns
      </div>
      <div class="col">
        One of three columns
      </div>
    </div>
  </div>
</div>
@endsection
