<!-- Stored in resources/views/pages/index.blade.php -->

@extends('layouts.mainlayout')

@section('title', 'Dispatch')

@section('sidebar')

@section('content')
<div class="wrapper">
    <div class="container">
        <div class="row">
            @include('layouts.sidenav')
            <div class="col text-center"> 
                <form method="POST" action="/register">
                {{ csrf_field() }}
                <h2>User Registration</h2>  

                <div class="form-group row"> 
                    <label class="col-sm-2" for="inputname">Name:</label>
                    <div class="col-sm-5">
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                </div>

                <div class="form-group row"> 
                    <label class="col-sm-2" for="inputeid">Employee ID:</label>
                    <div class="col-sm-5">
                        <input type="text" class="form-control" id="eid" name="eid">
                    </div>
                </div>

                <div class="form-group row"> 
                    <label class="col-sm-2" for="inputcid"> CID:</label>
                    <div class="col-sm-5">
                        <input type="text" class="form-control" id="cid" name="cid">
                    </div>
                </div>

                <div class="form-group row"> 
                    <label class="col-sm-2" for="email"> Email ID:</label>
                    <div class="col-sm-5">
                    <input type="email" class="form-control" id="email" name="email">
                    </div>
                </div>

                <div class="form-group row"> 
                    <label class="col-sm-2" for="email"> groups:</label>
                    <div class="col-sm-5">
                    <input type="text" class="form-control" id="email" name="email">
                    </div>
                </div>

                <div class="form-group row"> 
                    <label class="col-sm-2" for="designation"> Designation:</label>
                    <div class="col-sm-5">
                    <input type="text" class="form-control" id="designation" name="designation">
                    </div>
                </div>

                <div class="form-group row"> 
                    <label class="col-sm-2" for="office-no"> Office No:</label>
                    <div class="col-sm-5">
                    <input type="text" class="form-control" id="office-no" name="office-no">
                    </div>
                </div>
                
                <div class="form-group row"> 
                    <label class="col-sm-2" for="mobile-no"> Mobile No:</label>
                    <div class="col-sm-5">
                    <input type="text" class="form-control" id="mobile-no" name="mobile-no">
                    </div>
                </div>

                <div class="form-group row"> 
                    <label class="col-sm-2" for="password"> Password:</label>
                    <div class="col-sm-5">
                    <input type="password" class="form-control" id="password" name="password">
                    </div>
                </div>
 
                <div class="form-group row"> 
                    <div class="col-sm-6">
                    <button style="cursor:pointer" type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
       
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
