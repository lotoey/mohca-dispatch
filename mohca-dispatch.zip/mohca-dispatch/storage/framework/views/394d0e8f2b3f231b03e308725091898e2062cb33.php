<DOCTYPE HTML>
<html>
<head>
    <title></title>
<body>
    <h1>Create a new Projects</h1>
    <form method="POST" action="/projects"> 
    <?php echo e(csrf_field()); ?>

        <div>
            <input type="text" name="title" placeholder="Project Title">
        </div>

        <div>
            <input type="textarea" name= "description" placeholder="Project Description">
        </div>

        <div>
            <button type="submit">create button</button>
        </div>
    </form>
</body>
</head>
</html><?php /**PATH /Users/lotoey/code/project/resources/views/projects/create.blade.php ENDPATH**/ ?>