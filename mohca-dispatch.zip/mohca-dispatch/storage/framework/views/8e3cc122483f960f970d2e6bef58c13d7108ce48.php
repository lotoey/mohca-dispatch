<!-- Stored in resources/views/pages/index.blade.php -->



<?php $__env->startSection('title', 'Dispatch'); ?>

<?php $__env->startSection('sidebar'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <div class="container">
    <div class="row">
      <?php echo $__env->make('layouts.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col text-center"> 
          <br>
            <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row"> 
              <label class="col-sm-2" for="inputEmail4">Sent to:</label>
                <div class="col-sm-6">
                  <input type="email" class="form-control" id="inputEmail4" placeholder="Select User">
                </div>
            </div>

            <div class="form-group row">
              <label class="col-sm-2" for="inputEmail4">Cc:</label>
                <div class="col-sm-6">
                  <input type="email" class="form-control" id="inputEmail4" placeholder="Select User">
                </div>
            </div>
             
            <div class="form-group row"> 
              <label class="col-sm-2" for="inputSubject">Subject:</label>
                <div class="col-sm-6">
                  <input type="text" class="form-control" id="inputSubject" placeholder="Subject">
                </div>
            </div>
        
            <div class="form-group row"> 
              <label class="col-sm-2" for="inputSubject">Attach Document:</label>
                <div class="col-sm-4">
                  <input type="file" class="form-control-file" id="exampleFormControlFile1">
                </div>
            </div>
        
            <div class="form-group row">  
              <label class="col-sm-2" for="inputSubject">Action Date:</label>
                <div class="col-sm-3">
                  <input type="date" class="form-control" id="inputSubject" placeholder="Action Date">
                </div>
            </div>

            <div class="form-group row">  
              <div class="col-sm-5">
                  <input type="checkbox" aria-label="Checkbox for following text input" placeholder="Important">
                  <label for="inputSubject">Important</label>
              </div>
            </div>
           
            <div class="form-group row">
              <div class="col-sm-5">
                <button type="button" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-secondary">Send</button> 
              </div> 
            </div>
            
            <div class="form-group row">
              <div class="col-sm-6">
                <a class="btn btn-success" href="create-notification" role="button">Click here to send notification</a>
              </div>
            </div>
          </form>
      </div>
  </div>
</div>
          

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lotoey/code/mohca-dispatch/resources/views/pages/create.blade.php ENDPATH**/ ?>