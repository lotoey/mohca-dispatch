<?php echo e($slot); ?>

<?php /**PATH /Users/lotoey/code/mohca-dispatch/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>