
<nav class="navbar navbar-light bg-inverse navbar-fixed-top" style="background-color:orange">
     <div class="container d-flex justify-content-betIen">

     <button id="sidebarCollapse" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidebar" 
       aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
       </button>

       <h4>Nangsid Yegu Tonglen</h4>

      <span><!-- Search form -->
        <form class="form-inline active-cyan-3 active-cyan-4">
          
          <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
            aria-label="Search">
            <i class="fas fa-search" aria-hidden="true"></i></button>
        </form>
      </span>

      <!-- login -->
      <span>
      <a href="#"><i class="fas fa-user-plus"></i>&nbsp;Sign Up</a> &nbsp;&nbsp;
      <a href="#"><i class="fas fa-sign-in-alt"></i>&nbsp;Login</a
      </span>
     </div>

 </nav>

 <?php /**PATH /Users/lotoey/code/mohca_d/resources/views/layouts/nav.blade.php ENDPATH**/ ?>