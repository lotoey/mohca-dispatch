<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Dispatch, leave systems">
<meta name="author" content="ICT Division, Ministry of Home & Cultural Affairs">

<!-- Bootstrap 4.3.1 -->
<link rel="stylesheet" href="<?php echo e(asset('/assets/css/bootstrap-4.3.1.min.css')); ?>">

<title>MoHCA - <?php echo $__env->yieldContent('title'); ?></title> 

<?php /**PATH /Users/lotoey/code/mohca-dispatch/resources/views/layouts/head.blade.php ENDPATH**/ ?>