<!-- Stored in resources/views/pages/index.blade.php -->



<?php $__env->startSection('title', 'Dispatch'); ?>

<?php $__env->startSection('sidebar'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
<div class="container">
<div class="row">
  <?php echo $__env->make('layouts.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

  <table class= "table table-bordered table-sm" style="width:70%">
        <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">To</th>
                <th scope="col">Subject</th>
                <th scope="col">Date</th>
                <th scope="col">Letter</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">1</th>
                <td>Tashi</td>
                <td>Transfer order</td>
                <td>thumnail</td>
            </tr>
            <tr>
                <th scope="row">2</th>
                <td>Dorji</td>
                <td>Workshop</td>
                <td>Thumnail</td>
            </tr>

      
  </tbody>
</table>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lotoey/code/mohca-dispatch/resources/views/pages/outgoing.blade.php ENDPATH**/ ?>