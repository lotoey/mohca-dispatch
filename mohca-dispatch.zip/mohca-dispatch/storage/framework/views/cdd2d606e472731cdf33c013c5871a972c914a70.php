<footer class="text-muted fixed-bottom">
    <hr>
     <div class="container">
       <p class="float-right">
         <a href="#">Back to top</a>
       </p>
       <p>Crossponding Letters &copy; Ministry of Home & Cultural Affairs, 2019
     </div>
</footer><?php /**PATH /Users/lotoey/code/mohca-dispatch/resources/views/layouts/footer.blade.php ENDPATH**/ ?>