<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-3.3.1.slim.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap-4.3.1.min.js')); ?>"></script>

<script src="https://kit.fontawesome.com/83c73830af.js"></script>


<script>
    $(document).ready(function() {

        $('#sidebarCollapse').on('click', function() {
            $('#sidebar').toggleClass('active');
        });
    });
</script><?php /**PATH /Users/lotoey/code/mohca_d/resources/views/layouts/footer-scripts.blade.php ENDPATH**/ ?>